#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BLOCK_SIZE 512
#define BUFFER_BLOCK_COUNT 524288

void onBlock(char* block, int len, ssize_t addr) {
	if(!strncmp("GIF89a", block, len > 6 ? 6 : len)) {
		printf("Found signature for GIF file at %#016lx (Block: %#016lx)\n", addr, addr / BLOCK_SIZE);
	}
}

int main(int argc, char* argv[]) {
	if(argc < 2) {
		fprintf(stderr, "Must provide one argument for the volume path.\n");
		return -1;
	}
	
	int fd;
	
	fd = open(argv[1], O_RDONLY);
	
	if(fd < 0) {
		perror("Cannot open the named volume.\n");
		return -1;
	}
	
	char* buffer;
	buffer = malloc(BLOCK_SIZE * BUFFER_BLOCK_COUNT);
	
	ssize_t readAmt, bufferStart;
	
	bufferStart = 0;
	
	do {
		readAmt = read(fd, buffer, BLOCK_SIZE * BUFFER_BLOCK_COUNT);
		
		#if DEBUG
			printf("Scanning another %ld blocks at %#016lx (Block %#016lx).\n", (readAmt + BLOCK_SIZE - 1) / BLOCK_SIZE, bufferStart, bufferStart / BLOCK_SIZE);
		#endif
		
		int i;
		for(i = 0; i < readAmt; i += BLOCK_SIZE) {
			int actualSize;
			actualSize = readAmt - i;
			actualSize = actualSize > BLOCK_SIZE ? BLOCK_SIZE : actualSize;
			onBlock(buffer + i, actualSize, bufferStart + i);
		}
		
		bufferStart += readAmt;
	} while (readAmt > 0);
	
	free(buffer);
}
