#include "gif.h"

int isValidHeader(GIF* gif) {
	return gif->magicNumber[0] == 'G' &&
		gif->magicNumber[1] == 'I' &&
		gif->magicNumber[2] == 'F' && 
		gif->magicNumber[3] >= '0' && gif->magicNumber[3] <= '9' &&
		gif->magicNumber[4] >= '0' && gif->magicNumber[4] <= '9' &&
		gif->magicNumber[5] == 'a';
}

int isValidApplicationExtension(ApplicationExtension* ext) {
	return (ext->startSignature[0] & 0xff) == 0x21 &&
		(ext->startSignature[1] & 0xff) == 0xff;
}

int isValidFrame(Frame* ext) {
	return (ext->controlExtension.startSignature[0] & 0xff) == 0x21 &&
		(ext->controlExtension.startSignature[1] & 0xff) == 0xf9 &&
		(ext->imageDescriptor & 0xff) == 0x2c;
}

char* skipBlocks(char* ptr) {
	while((ptr[0] & 0xff) != 0) {
		ptr += ptr[0] & 0xff;
		ptr++;
	}
	ptr++;
	return ptr;
}

int isEndOfFile(Frame* ext) {
	return (ext->controlExtension.startSignature[0] & 0xff) == 0x3b;
}

UnpackedColorTableInfo unpackGCTInfo(ColorTable* table) {
	UnpackedColorTableInfo info;
	info.exists = table->packedTableInfo & 1;
	info.colorResolution = (table->packedTableInfo >> 1) & 7;
	info.sortFlag = (table->packedTableInfo >> 4) & 1;
	info.tableLength = 2 << ((table->packedTableInfo >> 5) & 7);
	return info;
}
