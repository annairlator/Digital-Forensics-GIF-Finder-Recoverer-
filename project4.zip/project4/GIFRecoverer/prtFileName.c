#include "debug.h"
#define _LARGEFILE64_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include "MFTentry.h"
#include "attribute.h"
#include "ctx.h"
#include "mbr.h"
#include <linux/types.h>

extern unsigned long long getMftAdd( int fd, DISK_mbr* mbrBuf );
extern void getAttrAdd(  MFTENTRY *mftentry, AttributeHeader **rfn, __u32 desiredType, FileCtx fCtx, void (*onCollision)(AttributeHeader**,AttributeHeader*, AttrCtx) );
extern void getFname( ResFnameAttrib *rfn, char *buf );


bool verifyFILE( unsigned char *mftMagic ) {


   if ( ( mftMagic[0] == 0x46 ) && ( mftMagic[1] == 0x49 ) && ( mftMagic[2] == 0x4c ) && ( mftMagic[3] == 0x45 ) ) {
      return (true);
   }
   else {
      return (false);
   }

}

/* Many entries will have two FILE_NAME attributes.
 * The second attribute has full file name.
 * The first FILE_NAME attribute has a truncated file name for
 * back ward compatibility, So even after finding the FILE_NAME Attribute,
 * we continue checking if there is a second FILE_NAME attribute
 */
void handleNameAttributeCollision (AttributeHeader **original, AttributeHeader *next, AttrCtx ctx) {
    ResFnameAttrib *rfn, *rfn2;
    rfn = (ResFnameAttrib *)*original;
    rfn2 = (ResFnameAttrib *)next;

    if ( rfn2->fnameAttr.filenameLength >= rfn->fnameAttr.filenameLength ) {
        *original = next;
        return;
    }
}


int printFile( int fd, unsigned long entryNum, int (*onEntry)(MFTENTRY*, FileCtx) ) {
   unsigned long long mftAddr;
   unsigned long long entryAddr;
   unsigned long long curloc;
   int retval;

   unsigned char b[SIZE_OF_CLUSTER];


   MFTENTRY *mft;
   unsigned char *mftMagic;
   
   FileCtx ctx;
   ctx.fd = fd;
   ctx.entryNum = entryNum;

#ifdef DEBUG
   printf("Enter printName\n" );
#endif

   mftAddr = getMftAdd( fd, &ctx.mbr );

   entryAddr = mftAddr + (entryNum * SIZE_OF_MFT_ENTRY );

   curloc = lseek64( fd, entryAddr, SEEK_SET );
   if ( curloc <=0 ) {
      fprintf( stderr, "printName: unable to lseek \n" );
      return 0;
   }

   retval = read(fd, b, SIZE_OF_CLUSTER );
   if ( retval < 0 ) {
      fprintf(stderr, "unable to read disk, retVal = %d\n", retval );
      return 0;
   }

   mft = (MFTENTRY *)b;

   mftMagic = mft->mftMagic;
   if ( verifyFILE( mftMagic ) == false ) {
      //fprintf( stderr, "prtMftEntry: FILE magic failed to verify\n" );
      return 0;
   }
   
   return onEntry(mft, ctx);
}
