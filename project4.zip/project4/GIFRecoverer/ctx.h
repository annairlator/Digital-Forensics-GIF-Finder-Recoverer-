#ifndef __CTX__
#define __CTX__

#include "mbr.h"
#include "MFTentry.h"

#define SIZE_OF_CLUSTER 4096

typedef struct fileCtx {
	int fd;
	unsigned long entryNum;
	DISK_mbr mbr;
} FileCtx;

typedef struct attrCtx {
	FileCtx fileCtx;
	MFTENTRY* mft;
} AttrCtx;

#endif
