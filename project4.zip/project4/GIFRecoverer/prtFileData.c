#include "debug.h"
#define _LARGEFILE64_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include "MFTentry.h"
#include "attribute.h"
#include <linux/types.h>
#include <string.h>
#include "ctx.h"

extern void getAttrAdd(  MFTENTRY *mftentry, AttributeHeader **rfn, __u32 desiredType, FileCtx fCtx, void (*onCollision)(AttributeHeader**,AttributeHeader*, AttrCtx) );
extern int onFileData(char* data, unsigned long length, unsigned long firstRunAddress);
unsigned long long getVbrAddr( DISK_mbr *mbr );

unsigned int readDataRuns(char* dest, int fd, char* runs, __u64 baseOffset, __u64 length) {
	int i;
	unsigned int firstRunAddress;
	__u64 currentOffset;
	currentOffset = 0;

	for(i = 0; true; i++) {
		unsigned int runOffsetSize, runLengthSize;
		runOffsetSize = ((unsigned int)runs[0]) >> 4;
		runLengthSize = ((unsigned int)runs[0]) & 0x0F;
		
		if(!runOffsetSize && !runLengthSize) {
			return firstRunAddress;
		}
		
		__u64 runLength;
		__s64 runOffset;
		runOffset = 0;
		runLength = 0;
		
		memcpy(&runLength, runs + 1, runLengthSize);
		memcpy(&runOffset, runs + runLengthSize + 1, runOffsetSize);
		runOffset = runOffset << 64 - 8 * runOffsetSize >> 64 - 8 * runOffsetSize;
		
		printf("Run #%d, offsetBytes = %d, lengthBytes = %d, clusterOffset = %lld, clusterLength = %lld\n", i, runOffsetSize, runLengthSize, runOffset, runLength);
		
		currentOffset += runOffset;
		if(lseek(fd, SIZE_OF_CLUSTER * currentOffset + baseOffset, SEEK_SET) <= 0) {
			fprintf( stderr, "readDataRuns: unable to lseek \n" );
			return 0;
		}
		
		if(i == 0) {
			firstRunAddress = SIZE_OF_CLUSTER * currentOffset + baseOffset;
		}
		
		ssize_t runBytes = SIZE_OF_CLUSTER * runLength;
		ssize_t blockReadAmt = read(fd, dest, runBytes < length ? runBytes : length);
		if(blockReadAmt < 0) {
			fprintf( stderr, "readDataRuns: unable to read \n" );
			return 0;
		}
		
		dest += blockReadAmt;
		length -= blockReadAmt;
		
		runs = runs + 1 + runOffsetSize + runLengthSize;
	}
}


int printData(AttributeHeader* standardHeader, AttrCtx ctx) {
	if(standardHeader != NULL) {
		char* data;
		unsigned long length, firstRunAddress;
		
	
		if(!standardHeader->nonResidentFlag) {
			//printf("DATA IS RESIDENT\n");
			
			ResidentExt* residentHeaders;
			residentHeaders = (ResidentExt*)(&standardHeader[1]);
			
			length = residentHeaders->attributeLength;
			
			data = malloc(sizeof(char) * length + 1);
			strncpy(data, ((char*)standardHeader) + residentHeaders->offsetToAttribute, length);
		} else {
			//printf("DATA IS NONRESIDENT\n");
			
			NonResidentExt* nonresidentHeaders;
			nonresidentHeaders = (NonResidentExt*)(&standardHeader[1]);
			
			length = nonresidentHeaders->realAttrSize;
			
			data = malloc(sizeof(char) * length + 1);
			firstRunAddress = readDataRuns(data, ctx.fileCtx.fd, ((char*)standardHeader) + nonresidentHeaders->datarunOffset, getVbrAddr(&ctx.fileCtx.mbr), length);
		}
		
		int returnCode;
		returnCode = onFileData(data, length, firstRunAddress);
		free(data);
		return returnCode;
		
	} else {
		//printf("NO DATA, IS PROBABLY A DIRECTORY OR EMPTY\n");
		return 0;
	}
}

void handleDataAttributeCollision(AttributeHeader** original, AttributeHeader* next, AttrCtx ctx) {
	printData(*original, ctx);
	*original = next;
}



int printFileData(MFTENTRY* entry, FileCtx fCtx) {
	AttributeHeader* standardHeader;
	standardHeader = NULL;
	
	AttrCtx aCtx;
	aCtx.fileCtx = fCtx;
	aCtx.mft = entry;
	
	getAttrAdd(entry, &standardHeader, ATTRIB_DATA_TYPE, fCtx, handleDataAttributeCollision );
	
	return printData(standardHeader, aCtx);
}
