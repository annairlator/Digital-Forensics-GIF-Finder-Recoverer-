#include "debug.h"
#include "attribute.h"
#include <stdio.h>


void getFname( ResFnameAttrib *rfn, char *buf ) {
   int len;
   int count;

#ifdef DEBUG
   printf("Enter getFname\n" );
#endif

   len = rfn->fnameAttr.filenameLength ;

#ifdef DEBUG
   printf("getFname: name length = %d\n", len );
#endif

   len = len * 2;
   count = 0;
   for ( int i = 0; i < len ; i++ ) {

#ifdef DEBUG
       printf("%c", rfn->fnameAttr.fileName[i] );
#endif
       buf[count] = rfn->fnameAttr.fileName[i];
       i++;  // skip 0x00 in name
       count++;
   }
#ifdef DEBUG
   printf("\n");
#endif
   buf[count] = '\0';

}





