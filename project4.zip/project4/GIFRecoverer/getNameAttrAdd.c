#include "debug.h"
#include <endian.h>
#include "MFTentry.h"
#include "attribute.h"
#include "ctx.h"
#include <stdio.h>


void getAttrAdd(  MFTENTRY *mftentry, AttributeHeader **rfn, __u32 desiredType, FileCtx fCtx, void (*onCollision)(AttributeHeader**, AttributeHeader*, AttrCtx) ) {
   unsigned short attribOffset;
   AttributeHeader *attribHdr;
   unsigned char *tmp;
   unsigned int count;
   __u32 type;
   __u32 length;
   
   AttrCtx aCtx;
   aCtx.fileCtx = fCtx;
   aCtx.mft = mftentry;

#ifdef DEBUG
   printf("Enter getNameAttrAdd\n");
   printf("entry = %p\n", (void *)mftentry );
#endif

   attribOffset = le16toh(mftentry->attrOffset);

#ifdef DEBUG
   printf("getNameAttrAdd attriboffset = 0x%x\n", attribOffset );
#endif

   tmp = (unsigned char *)mftentry;
    
   tmp = tmp + attribOffset;    // 1st attribute
   count = attribOffset;

   attribHdr = ( AttributeHeader *) tmp;
   type = le32toh(attribHdr->type);

#ifdef DEBUG
   printf("getNameAttrAdd type = 0x%lx\n", type );
#endif

   length = le32toh( attribHdr->length ); 
#ifdef DEBUG
   printf("getNameAttrAdd length = 0x%lx\n", length );
#endif

   count = length + count;

#ifdef DEBUG
   printf("getNameAttrAdd count = 0x%x\n", count );
#endif

   while ( type != ATTRIBUTE_LIST_TERMINATOR ) {

       if ( count > 0x400 ) {
           fprintf(stderr, "getNameAttrbAdd: ERROR, NO NAME ATTRIBUTE FOUND \n" );
           return;
       }

       if ( type == desiredType ) {

           if ( *rfn == NULL ) {

              *rfn = ( AttributeHeader *) tmp;
           }
           else {
              if(onCollision != NULL) {
                  onCollision(rfn, ( AttributeHeader *) tmp, aCtx);
              }
           }

       }

       length = le32toh( attribHdr->length );
#ifdef DEBUG
       printf("getNameAttrAdd length = 0x%x\n", length );
#endif

       count = length + count;
       if ( count > 0x400 ) {
           fprintf(stderr, "getNameAttrbAdd: ERROR, count greater than entry size %d\n", count );
           return;
       }
       tmp = tmp + length;
       attribHdr = ( AttributeHeader *) tmp;
       type = le32toh(attribHdr->type);

#ifdef DEBUG
       printf("getNameAttrAdd type = 0x%lx\n", type );
       printf("getNameAttrAdd count = 0x%x\n", count );
#endif

   }

   return;

}
