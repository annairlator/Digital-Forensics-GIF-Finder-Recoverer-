/*
 * 	An MFT Entry is a 1KB (0x400 Byte) data structure that contains information about
 * 	each file and directory on disk.  It is structured as follows:
 * 
 * 	------------------------------------
 * 	|          RECORD HEADER           |
 * 	|----------------------------------|
 * 	|	        ATTRIBUTE 1            |
 * 	|           ATTRIBUTE 2            |
 * 	|               ...                |
 * 	|           ATTRIBUTE N            |
 * 	------------------------------------
 * 
 * 	Attributes are defined in Attribute.h
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

#ifndef __MFTENTRY
#define __MFTENTRY

#include <linux/types.h>

#define SIZE_OF_MFT_ENTRY       0x400

#define MFT_ENTRY_INDX  0

#define FLAG_DIRECTORY 0x2
#define FLAG_INUSE 0x1
#define FLAG_FILE_DELETED 0x0
#define FLAG_DIR_DELETED 0x2
#define FLAG_DIR_INUSE 0x3

typedef struct MFTentry {
	/* 0x00 */	__u8 mftMagic[4];
	/* 0x04 */	__u16 updateSeqOffset;
	/* 0x06 */	__u16 updateSeqSize;
	/* 0x08 */	__u64 lsn;
	/* 0x10 */	__u16 seqNum;
	/* 0x12 */	__u16 hardLinkCount;
	/* 0x14 */	__u16 attrOffset;
	/* 0x16 */	__u16 flags;				// 0x01 = in use, 0x02 = directory
	/* 0x18 */	__u32 recordRealSize;
	/* 0x1C */	__u32 recordAllocSize;
	/* 0x20 */	__u64 baseFileRef;
	/* 0x28 */	__u16 nextAttrId;
	/* 0x2A */	__u16 highBitRecId;
	/* 0x2C */	__u32 lowBitRecId;
	/* 0x30 */	__u32 unused;
        /* 0x34 */      __u8  attrib[972];
} MFTENTRY;

#endif
