#pragma once

#include <linux/types.h>

typedef struct colorTable {
	__u8 packedTableInfo;
	__u8 backgroundColor;
	__u8 defaultPixelRatio;
	char tableData[768];
} __attribute__((packed)) ColorTable;

//Asserts a stndard shape for the graphic control extension
typedef struct controlExtension {
	char startSignature[2];
	__u8 size;
	__u8 flags0;
	__u16 frameDelay1;
	__u8 transparentIndex2;
	char endSignature;
} __attribute__((packed)) ControlExtension;

typedef struct unpackedColorTableInfo {
	int exists;
	unsigned int colorResolution;
	int sortFlag;
	unsigned int tableLength;
} UnpackedColorTableInfo;

// Asserts common GIF file behavior of having just 1 netscape block
// which contains just repetition count
typedef struct applicationExtension {
	char startSignature[2];
	__u8 nameSize;
	char name[11];
	__u8 extBlockSize;
	__u8 index0;
	__u16 repetitions0;
	__u8 blockEnd;
} __attribute__((packed)) ApplicationExtension;

typedef struct frame {
	ControlExtension controlExtension;
	__u8 imageDescriptor;
	__u16 left;
	__u16 top;
	__u16 width;
	__u16 height;
	__u8 flags;
	__u8 minCodeSize;
	char rest[1];
} __attribute__((packed)) Frame;

typedef struct gif {
	char magicNumber[6];
	__u16 screenWidth;
	__u16 screenHeight;
	ColorTable colorTable;
	ApplicationExtension applicationExtension;
	char rest[1];
} __attribute__((packed)) GIF;
