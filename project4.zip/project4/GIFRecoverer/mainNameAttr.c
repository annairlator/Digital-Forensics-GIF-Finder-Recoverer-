#include "debug.h"
#include "MFTentry.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "ctx.h"
#include "gif.h"

int printFile( int fd, unsigned long entrynum, int (*onEntry)(MFTENTRY*, FileCtx) );

void printFileName(MFTENTRY*, FileCtx);
int printFileData(MFTENTRY*, FileCtx);

extern int isValidHeader(GIF* gif);
extern UnpackedColorTableInfo unpackGCTInfo(ColorTable* table);
extern int isValidApplicationExtension(ApplicationExtension* ext);

extern int isValidFrame(Frame* ext);
extern int isEndOfFile(Frame* ext);

char* skipBlocks(char* ptr);

int destFd;
unsigned long targetAddress;

extern int onFileData(char* data, unsigned long length, unsigned long firstRunAddress) {
	if(firstRunAddress == targetAddress) {
		printf("GIF file found. Writing to recovery file.\n");
		write(destFd, data, length);
		return 1;
	}
	return 0;
}

int handleMftEntry(MFTENTRY* mft, FileCtx ctx) {
        return printFileData(mft, ctx);
}

int main(int argc, char** argv) {
        int fd;
        short arg2Len;
        bool ret;

        arg2Len = strlen(argv[1]);
#ifdef DEBUG
        printf("main: arglen =  %d\n", arg2Len );
#endif

        if ( arg2Len != 8 ) {
           fprintf(stderr, "(0)USAGE: %s /dev/sdx /recovery/file/location <known_location>\n", argv[0]);
           return(0);
        }

        if(argc != 4) {
           fprintf(stderr, "(0)USAGE: %s /dev/sdx /recovery/file/location <known_location>\n", argv[0]);
           return(0);
        }

        fd = open(argv[1], O_RDONLY);
        if ( fd < 0 )
        {
                fprintf(stderr, "device not opened = %s \n", argv[1] );
                return(0);
        }
        destFd = open(argv[2], O_CREAT | O_RDWR);
        if ( destFd < 0 )
        {
                fprintf(stderr, "device not opened = %s \n", argv[2] );
                return(0);
        }
        
        targetAddress = strtoul(argv[3], NULL, 0);
#ifdef DEBUG
        printf("main: entry =  %d\n", entry );
#endif
	int i, status;
	for(i = 0; true; i++) {
        	status = printFile( fd , i, handleMftEntry );
        	if(status) {
        		break;
        	}
        	lseek(fd, SEEK_SET, 0);
        }
        close( fd );
        close( destFd );
}

