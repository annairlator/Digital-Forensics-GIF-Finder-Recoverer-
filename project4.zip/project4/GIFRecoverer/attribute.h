#ifndef __ATTRIBUTE__
#define __ATTRIBUTE__

#include <linux/types.h>


// Attribute Types
#define ATTRIB_STANDARD_INFORMATION_TYPE 0x10
#define ATTRIB_FILE_NAME_TYPE 0x30
#define ATTRIB_DATA_TYPE 0x80
#define ATTRIB_INDEX_ROOT_TYPE 0x90
#define ATTRIB_INDEX_ALLOCATION_TYPE 0xA0
#define ATTRIB_BITMAP_TYPE 0xB0

#define ATTRIBUTE_LIST_TERMINATOR 0xFFFFFFFF
#define CLUSTER_RUN_END 0x00
#define CLUSTER_RUN_HEADER_SIZE 0x1

#define MAX_FNAME_SIZE	256

#define RESFLAG 0x0
#define NONRESFLAG 0x1

typedef struct dataRunNode {
   __u32 startingCluster;
   __u32 numOfClusters;
   struct dataRunNode *next;

} DataRunNode;

typedef struct attributeHeader {
	/* 0x00 */	__u32 type;			// attribute type (e.g., 0x10, 0x80)
	/* 0x04 */	__u32 length;			// length including this header
	/* 0x08 */	__u8  nonResidentFlag;		// 0 = resident, 1 = non-resident
	/* 0x09 */	__u8  nameLength;		// if named (N chars), then length = 2N
	/* 0x0A */	__u16 offsetToName;		// either 0x00, 0x18, or 0x40
	/* 0x0C */	__u16 flags;			// 0x01 = Compressed, 0x4000 = Encrypted, 0x8000 = Sparse
	/* 0x0E */	__u16 attributeId;		// each attribute has a unique identifier
        // /* 0x10 */      __u8  restA[1];               // rest of attribute
}  AttributeHeader; 
	
typedef struct Residentext {
	/* 0x10 */	__u32 attributeLength;		// length of attribute data
	/* 0x14 */	__u16 offsetToAttribute;	// rounded up to a multiple of 4 bytes
	/* 0x16 */	__u8  indexedFlag;
	/* 0x17 */	__u8  padding;
        // /* 0x18 */      __u8  attribute[1];		// The attribute itself
} ResidentExt;

typedef struct NonResidentext {
	/* 0x10 */	__u64 startingVCN;
	/* 0x18 */	__u64 lastVCN;
	/* 0x20 */	__u16 datarunOffset;		// either 0x40 or 0x40+2N
	/* 0x22 */	__u16 compressionUnitSize;	// unit size = 2^x clusters. 0 => uncompressed
	/* 0x24 */	__u8  padding[4];
	/* 0x28 */	__u64 allocAttrSize;		// rounded up to the cluster size
	/* 0x30 */	__u64 realAttrSize;		// real size of the attribute
	/* 0x38 */	__u64 initStreamSize;		// compressed data size
} NonResidentExt;
	

// $FILE_NAME = 0x30, always resident

typedef struct fileNameAttrib {
	/* 0x00 */	__u64 fileRef;			// file reference to the parent directory 
						// (6 bytes FILE record number + 2 bytes sequence number)
	/* 0x08 */	__u64 fileCreation;
	/* 0x10 */	__u64 fileAltered;
	/* 0x18 */	__u64 mftChanged;
	/* 0x20 */	__u64 fileRead;
	/* 0x28 */	__u64 allocSize;
	/* 0x30 */	__u64 realSize;
	/* 0x38 */	__u32 flags;				// see below
	/* 0x3C */	__u32 reparse;
	/* 0x40 */	__u8  filenameLength;
	/* 0x41 */	__u8  fileNamespace;
	/* 0x42 */	__u8  fileName[1];
	
	/* Flags
	 * 0x0001 = Read-Only
	 * 0x0002 = Hidden
	 * 0x0004 = System
	 * 0x0020 = Archive
	 * 0x0040 = Device
	 * 0x0080 = Normal
	 * 0x0100 = Temporary
	 * 0x0200 = Sparse File
	 * 0x0400 = Reparse Point
	 * 0x0800 = Compressed
	 * 0x1000 = Offline
	 * 0x2000 = Not Content Indexed
	 * 0x4000 = Encrypted
	 * 0x10000000 = Directory (copy from corresponding bit in MFT record)
	 * 0x20000000 = Index View (copy from corresponding bit in MFT record)
	 */
}FileNameAttrib;
	
// $STANDARD_INFORMATION = 0x10, always resident

struct StandardInformationHeader {
	/* 0x00 */	__u64 fileCreation;
	/* 0x08 */	__u64 fileAltered;
	/* 0x10 */	__u64 mftChanged;
	/* 0x18 */	__u64 fileRead;
	/* 0x20 */	__u32 dosFilePermissions;
	/* 0x24 */	__u32 maxNumVersions;
	/* 0x28 */	__u32 versionNum;
	/* 0x2C */	__u32 classId;
	/* 0x30 */	__u32 ownerId;
	/* 0x34 */	__u32 securityId;
	/* 0x38 */	__u64 quotaCharged;
	/* 0x40 */	__u64 usn;
	
};

typedef struct ResFname {
	AttributeHeader attrHeader;
        ResidentExt ext;
        FileNameAttrib fnameAttr;
} ResFnameAttrib;


// $DATA = 0x80
// if resident then data is real data
// if non-resident then data is cluster runs

typedef struct ResData {
	AttributeHeader attrHeader;
        ResidentExt ext;
	__u8  data[1];
} ResDataAttrib;

typedef struct NonResData {
	AttributeHeader attrHeader;
        NonResidentExt ext;
	__u8  data[1];
} NresDataAttrib;

struct ClusterRun {
	__u64 offset;
	__u64 length;
	
};


// $BITMAP = 0xB0
// attribute used in two places: indexes (e.g., directories) and $MFT

struct Bitmap {
	AttributeHeader attrHeader;
	__u8  *bitfield;
	__u64 bitfieldLength;
	
};

#endif
